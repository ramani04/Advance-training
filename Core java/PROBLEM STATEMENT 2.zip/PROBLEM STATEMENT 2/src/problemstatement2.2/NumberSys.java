package problemstatement2;

class Main {
  public static void main(String[] args) {

    int i = 1, n = 20, firstTerm = 0, secondTerm = 1;
    System.out.println("Fibonacci Series from "+ i + " to " + n + " terms:");

    while (i <= n) {
      System.out.print(firstTerm + ", ");

      int nextTerm = firstTerm + secondTerm;
      firstTerm = secondTerm;
      secondTerm = nextTerm;

      i++;
    }
  }
}