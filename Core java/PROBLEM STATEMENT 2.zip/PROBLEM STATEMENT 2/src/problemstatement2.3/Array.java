package problemstatement3;

public class Array {  
	public static void main(String[] args) {  
		 int sum = 0;  
		 int avg= 0;  
        int arr[]  = {3,2,4,5,6,4,5,7,3,2,3,4,7,1,2,0,0,0};  
        int larg=arr[0];
        for (int i = 0; i < arr.length-3; i++) {  
           sum = sum + arr[i];  
           avg=sum/2;
           if(larg>arr[i]) {
        	   larg=arr[i];
           }
        }  
        arr[15]=sum;
        arr[16]=avg;
        arr[17]=larg;
        for(int v:arr) {
        System.out.println(" " + v);  
        }
    }  
}  