package problemstatement2;

class AgeNotWithInRangeException extends Exception
{
     public String toString()
     {
          return ("Age is not between 15 and 25. please ReEnter the Age");
     }
}